import os

def clear_terminal():
    os.system('cls')